package com.meegoreborn

import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    private lateinit var appRepository: AppRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appRepository = AppRepository(this)
        val prefs = getSharedPreferences("n9_preferences", MODE_PRIVATE)
        setContent {
            MeeGoRebornApp(
                apps = appRepository.loadLaunchableApps(),
                initialMode = if (prefs.getString("mode", "HYBRID") == "CLASSIC") UiMode.CLASSIC else UiMode.HYBRID,
                onModeChanged = { prefs.edit().putString("mode", it.name).apply() },
                onRefreshApps = { appRepository.loadLaunchableApps() },
                onLaunchApp = ::launchApp,
                onHomeShortcut = ::launchHomeShortcut,
                onRequestHomeRole = ::requestHomeRole
            )
        }
    }

    private fun launchApp(tile: AppTile) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(tile.packageName, tile.activityName))
        safelyStart(intent)
    }

    private fun launchHomeShortcut(kind: ShortcutKind) {
        val intent = when (kind) {
            ShortcutKind.PHONE -> Intent(Intent.ACTION_DIAL)
            ShortcutKind.CONTACTS -> Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
            ShortcutKind.MESSAGES -> Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))
            ShortcutKind.BROWSER -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com"))
        }
        safelyStart(intent)
    }

    private fun safelyStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No compatible app is installed", Toast.LENGTH_SHORT).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "Android blocked this action", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestHomeRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME) && !roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
                startActivity(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME))
            } else if (roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
                Toast.makeText(this, "N9 is already the default Home app", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Choose N9 from Android Home app settings", Toast.LENGTH_LONG).show()
        }
    }
}
