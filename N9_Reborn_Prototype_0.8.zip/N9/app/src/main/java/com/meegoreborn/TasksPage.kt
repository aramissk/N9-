package com.meegoreborn

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable

@Composable
fun TasksPage(classic: Boolean, accent: Color) {
    Column(Modifier.fillMaxSize()) {
        Text("Open applications", color = Color.White, fontSize = 27.sp, modifier = Modifier.padding(vertical = 18.dp))
        repeat(3) { index ->
            Card(Modifier.fillMaxWidth().padding(bottom = 12.dp).height(112.dp),
                shape = RoundedCornerShape(if (classic) 7.dp else 17.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .10f))) {
                Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    val icons = listOf(Icons.Default.Language, Icons.Default.Photo, Icons.Default.MusicNote)
                    val names = listOf("Browser", "Gallery", "Music")
                    val tints = listOf(Color(0xFF168FE5), Color(0xFF75C900), Color(0xFFE52C8A))
                    Surface(shape = RoundedCornerShape(10.dp), color = tints[index], modifier = Modifier.size(58.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(icons[index], null, tint = Color.White) }
                    }
                    Spacer(Modifier.width(14.dp))
                    Column { Text(names[index], color = Color.White); Text("Preview card • not a live task", color = Color.White.copy(alpha = .6f), fontSize = 11.sp) }
                }
            }
        }
        Text("Real recent-app management is not implemented in this build.", color = Color.White.copy(alpha = .55f), fontSize = 11.sp)
    }
}
