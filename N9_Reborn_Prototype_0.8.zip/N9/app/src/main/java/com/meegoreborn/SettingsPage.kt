package com.meegoreborn

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsPage(mode: UiMode, onMode: (UiMode) -> Unit, onBack: () -> Unit, onRequestHomeRole: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Appearance", color = Color.White, fontSize = 27.sp, modifier = Modifier.padding(vertical = 18.dp))
        Text("Choose your MeeGo experience", color = Color.White.copy(alpha = .7f), fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        listOf(UiMode.CLASSIC, UiMode.HYBRID).forEach { option ->
            val selected = mode == option
            Card(onClick = { onMode(option) }, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(
                    containerColor = if (selected) Color(0xFF16466F) else Color.White.copy(alpha = .08f))) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (option == UiMode.CLASSIC) "Classic 2011" else "Hybrid Modern", color = Color.White)
                        Text(if (option == UiMode.CLASSIC) "Faithful, nostalgic styling" else "Classic identity with modern polish",
                            color = Color.White.copy(alpha = .65f), fontSize = 11.sp)
                    }
                    RadioButton(selected = selected, onClick = { onMode(option) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onRequestHomeRole, modifier = Modifier.fillMaxWidth()) { Text("Set as default Home app") }
        Text("Android will ask you to confirm the default launcher.", color = Color.White.copy(alpha = .55f), fontSize = 11.sp,
            modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Text("MeeGo Reborn • Prototype 0.8", color = Color.White.copy(alpha = .45f), fontSize = 11.sp)
        TextButton(onClick = onBack) { Text("Back to home", color = Color(0xFF48B8F2)) }
    }
}
