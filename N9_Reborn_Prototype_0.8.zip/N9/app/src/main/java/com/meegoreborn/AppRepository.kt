package com.meegoreborn

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable

class AppRepository(private val context: Context) {
    fun loadLaunchableApps(): List<AppTile> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (android.os.Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return resolved.mapNotNull { info ->
            val activityInfo = info.activityInfo ?: return@mapNotNull null
            AppTile(
                name = info.loadLabel(pm).toString(),
                packageName = activityInfo.packageName,
                activityName = activityInfo.name,
                icon = drawableToBitmap(info.loadIcon(pm))
            )
        }.distinctBy { it.packageName to it.activityName }
            .sortedBy { it.name.lowercase() }
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        val width = (if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96).coerceAtMost(192)
        val height = (if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96).coerceAtMost(192)
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmap ->
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
        }
    }
}
