package com.meegoreborn

import android.graphics.Bitmap

enum class UiMode { CLASSIC, HYBRID }
enum class LauncherPage { HOME, APPS, TASKS, SETTINGS }

data class AppTile(
    val name: String,
    val packageName: String,
    val activityName: String,
    val icon: Bitmap
)

data class HomeShortcutSpec(
    val label: String,
    val kind: ShortcutKind
)

enum class ShortcutKind { PHONE, CONTACTS, MESSAGES, BROWSER }
