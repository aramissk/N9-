package com.meegoreborn

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

@Composable
fun MeeGoRebornApp(
    apps: List<AppTile>,
    initialMode: UiMode,
    onModeChanged: (UiMode) -> Unit,
    onRefreshApps: () -> List<AppTile>,
    onLaunchApp: (AppTile) -> Unit,
    onHomeShortcut: (ShortcutKind) -> Unit,
    onRequestHomeRole: () -> Unit
) {
    var mode by remember { mutableStateOf(initialMode) }
    var page by remember { mutableStateOf(LauncherPage.HOME) }
    var dragTotal by remember { mutableFloatStateOf(0f) }
    var currentApps by remember(apps) { mutableStateOf(apps) }
    val classic = mode == UiMode.CLASSIC
    val accent = if (classic) Color(0xFF14A9E8) else Color(0xFF48B8F2)
    val background = if (classic) Color(0xFF05070D) else Color(0xFF07172D)

    Surface(Modifier.fillMaxSize(), color = background) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    if (classic) listOf(Color(0xFF02040A), Color(0xFF10192B), Color(0xFF03050A))
                    else listOf(Color(0xFF06152B), Color(0xFF102D55), Color(0xFF030A17))
                )
            ).pointerInput(page) {
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, amount -> dragTotal += amount },
                    onDragEnd = {
                        if (dragTotal < -65f) page = when (page) {
                            LauncherPage.HOME -> LauncherPage.APPS
                            LauncherPage.APPS -> LauncherPage.TASKS
                            else -> LauncherPage.HOME
                        }
                        if (dragTotal > 65f) page = when (page) {
                            LauncherPage.TASKS -> LauncherPage.APPS
                            LauncherPage.APPS -> LauncherPage.HOME
                            else -> LauncherPage.HOME
                        }
                        dragTotal = 0f
                    }
                )
            }
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                StatusBar(accent)
                AnimatedContent(
                    targetState = page,
                    transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(120)) },
                    label = "launcher-page"
                ) { target ->
                    when (target) {
                        LauncherPage.HOME -> HomePage(classic, accent, onApps = { page = LauncherPage.APPS },
                            onSettings = { page = LauncherPage.SETTINGS }, onShortcut = onHomeShortcut)
                        LauncherPage.APPS -> AppsPage(currentApps, classic, accent,
                            onRefreshApps = { currentApps = onRefreshApps() }, onLaunchApp = onLaunchApp)
                        LauncherPage.TASKS -> TasksPage(classic, accent)
                        LauncherPage.SETTINGS -> SettingsPage(mode, onMode = { mode = it; onModeChanged(it) },
                            onBack = { page = LauncherPage.HOME }, onRequestHomeRole = onRequestHomeRole)
                    }
                }
            }
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                repeat(3) { index ->
                    val selected = page.ordinal.coerceAtMost(2) == index
                    Box(Modifier.padding(horizontal = 5.dp).size(if (selected) 8.dp else 6.dp)
                        .clip(CircleShape).background(if (selected) Color.White else Color.White.copy(alpha = .35f)))
                }
            }
            TextButton(onClick = { page = LauncherPage.SETTINGS },
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 36.dp)) {
                Text("MODE", color = accent)
            }
        }
    }
}
