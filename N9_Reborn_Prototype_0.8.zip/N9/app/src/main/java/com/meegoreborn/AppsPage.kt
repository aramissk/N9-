package com.meegoreborn

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AppsPage(tiles: List<AppTile>, classic: Boolean, accent: Color,
             onRefreshApps: () -> Unit, onLaunchApp: (AppTile) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filteredTiles = remember(tiles, query) { tiles.filter { it.name.contains(query.trim(), ignoreCase = true) } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Applications", color = Color.White, fontSize = 27.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = onRefreshApps) { Icon(Icons.Default.Refresh, "Refresh apps", tint = accent) }
        }
        OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search apps", color = Color.White.copy(alpha = .55f)) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = accent) },
            modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = accent, unfocusedBorderColor = Color.White.copy(alpha = .35f), cursorColor = accent))
        LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 76.dp), modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(22.dp),
            contentPadding = PaddingValues(bottom = 70.dp)) {
            items(filteredTiles, key = { it.packageName + "/" + it.activityName }) { tile ->
                Column(Modifier.fillMaxWidth().clickable { onLaunchApp(tile) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(tile.icon.asImageBitmap(), tile.name,
                        Modifier.size(if (classic) 55.dp else 59.dp).clip(RoundedCornerShape(if (classic) 15.dp else 19.dp)))
                    Spacer(Modifier.height(6.dp))
                    Text(tile.name, color = Color.White, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
        if (filteredTiles.isEmpty()) Text(if (tiles.isEmpty()) "No launchable apps found" else "No matching apps",
            color = Color.White.copy(alpha = .65f), modifier = Modifier.padding(12.dp))
    }
}
