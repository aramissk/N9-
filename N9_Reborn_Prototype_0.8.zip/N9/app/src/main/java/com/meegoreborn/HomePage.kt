package com.meegoreborn

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

@Composable
fun HomePage(classic: Boolean, accent: Color, onApps: () -> Unit, onSettings: () -> Unit,
             onShortcut: (ShortcutKind) -> Unit) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) { now = LocalDateTime.now(); delay(1000) }
    }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(34.dp))
        Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White,
            fontSize = 58.sp, fontWeight = FontWeight.Light)
        Text(now.format(DateTimeFormatter.ofPattern("EEEE  •  dd MMMM")).uppercase(),
            color = Color.White.copy(alpha = .72f), fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(42.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            HomeShortcut("Phone", Icons.Default.Call, Color(0xFF75C900)) { onShortcut(ShortcutKind.PHONE) }
            HomeShortcut("Contacts", Icons.Default.Person, Color(0xFF168FE5)) { onShortcut(ShortcutKind.CONTACTS) }
            HomeShortcut("Messages", Icons.Default.ChatBubble, Color(0xFF16A5D8)) { onShortcut(ShortcutKind.MESSAGES) }
            HomeShortcut("Browser", Icons.Default.Language, Color(0xFF1789C8)) { onShortcut(ShortcutKind.BROWSER) }
        }
        Spacer(Modifier.height(36.dp))
        Card(Modifier.fillMaxWidth().height(118.dp), shape = RoundedCornerShape(if (classic) 8.dp else 20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = if (classic) .07f else .11f))) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
                Text(if (classic) "Nokia N9 • Classic experience" else "MeeGo Reborn • Hybrid",
                    color = Color.White, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(7.dp))
                Text("Swipe left for apps  •  Swipe right to return",
                    color = Color.White.copy(alpha = .7f), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            androidx.compose.material3.TextButton(onClick = onApps) { Text("All apps", color = accent) }
            androidx.compose.material3.TextButton(onClick = onSettings) { Text("Settings", color = accent) }
        }
        Spacer(Modifier.height(42.dp))
    }
}

@Composable
private fun HomeShortcut(label: String, icon: ImageVector, tint: Color, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)).background(tint), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}
