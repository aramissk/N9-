# N9 Reborn Prototype 0.8

An Android launcher prototype inspired by Nokia N9 / MeeGo Harmattan.

## What's changed in 0.8
- Split the former single-file UI into focused Kotlin files for models, app discovery, launcher navigation, status bar, home, app drawer, settings, and the task-preview page.
- Added a real Android Home-role request from Settings on Android 10 and newer. Android displays its own confirmation UI; the app does not silently change the default launcher.
- Separated the standard app-launcher intent filter from the HOME intent filter.
- Connected the four home shortcuts to Android intents: Dialer, Contacts, SMS composer, and web browser. The selected compatible Android app handles each action.
- Replaced the hard-coded home-screen clock/date with the device's current local time and date.
- Changed the app drawer from a fixed four-column grid to an adaptive grid.
- Bumped version metadata and the GitHub Actions artifact name to 0.8.

## Known limitations
- This source archive has not yet been built by GitHub Actions for 0.8. No APK is included.
- The task-preview page is still illustrative; Android's real recent-task management is not implemented.
- Wi-Fi and battery symbols in the in-app status strip are still decorative. The native Android status bar remains separate.
- QUERY_ALL_PACKAGES is retained for the prototype's broad app-drawer discovery. A public Google Play release would need a package-visibility and policy review.
- Home-role selection is requested through Android's RoleManager and must be confirmed by the user on-device. It has not yet been tested on the Poco X3 GT.
- Performance and 60/120 Hz frame pacing have not been measured.

## Build
Open GitHub Actions and run **Build N9 APK** manually. The expected artifact name is `N9-APK-v0.8`.
