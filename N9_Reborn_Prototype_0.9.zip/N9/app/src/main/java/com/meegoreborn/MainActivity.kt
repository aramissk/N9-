package com.meegoreborn

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    private fun loadLaunchableApps(): List<AppTile> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (android.os.Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return resolved.mapNotNull { info ->
            val activityInfo = info.activityInfo ?: return@mapNotNull null
            AppTile(info.loadLabel(pm).toString(), activityInfo.packageName, activityInfo.name, drawableToBitmap(info.loadIcon(pm)))
        }.distinctBy { it.packageName to it.activityName }.sortedBy { it.name.lowercase(Locale.getDefault()) }
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        val w = (drawable.intrinsicWidth.takeIf { it > 0 } ?: 96).coerceAtMost(192)
        val h = (drawable.intrinsicHeight.takeIf { it > 0 } ?: 96).coerceAtMost(192)
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { bitmap ->
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("n9_preferences", MODE_PRIVATE)
        setContent {
            var apps by remember { mutableStateOf(loadLaunchableApps()) }
            MeeGoRebornApp(
                apps = apps,
                initialMode = if (prefs.getString("mode", "HYBRID") == "CLASSIC") UiMode.CLASSIC else UiMode.HYBRID,
                onModeChanged = { prefs.edit().putString("mode", it.name).apply() },
                onRefreshApps = { apps = loadLaunchableApps() },
                onLaunchApp = { launchTile(it) },
                onLaunchShortcut = { launchShortcut(it) }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh app list when returning from installing/removing an app.
        window.decorView.post { /* UI refresh button remains available if the package list changed. */ }
    }

    private fun launchTile(tile: AppTile) {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(tile.packageName, tile.activityName)))
        } catch (_: Exception) {
            packageManager.getLaunchIntentForPackage(tile.packageName)?.let { startActivity(it) }
                ?: Toast.makeText(this, "این برنامه قابل اجرا نیست", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchShortcut(shortcut: Shortcut) {
        val intents = when (shortcut) {
            Shortcut.PHONE -> listOf(Intent(Intent.ACTION_DIAL))
            Shortcut.CONTACTS -> listOf(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
            Shortcut.MESSAGES -> listOf(Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_MESSAGING"), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
            Shortcut.BROWSER -> listOf(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")))
            Shortcut.CALENDAR -> listOf(Intent(Intent.ACTION_VIEW).setData(CalendarContract.CONTENT_URI), Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_CALENDAR"))
        }
        for (intent in intents) {
            try { startActivity(intent); return } catch (_: ActivityNotFoundException) { } catch (_: SecurityException) { }
        }
        Toast.makeText(this, "برنامهٔ سازگار روی گوشی پیدا نشد", Toast.LENGTH_SHORT).show()
    }
}

private enum class UiMode { CLASSIC, HYBRID }
private enum class Page { HOME, APPS, TASKS, SETTINGS }
private enum class Shortcut { PHONE, CONTACTS, MESSAGES, BROWSER, CALENDAR }
private data class AppTile(val name: String, val packageName: String, val activityName: String, val icon: Bitmap)

@Composable
private fun MeeGoRebornApp(
    apps: List<AppTile>, initialMode: UiMode, onModeChanged: (UiMode) -> Unit,
    onRefreshApps: () -> Unit, onLaunchApp: (AppTile) -> Unit, onLaunchShortcut: (Shortcut) -> Unit
) {
    var mode by remember { mutableStateOf(initialMode) }
    var page by remember { mutableStateOf(Page.HOME) }
    var dragTotal by remember { mutableFloatStateOf(0f) }
    val classic = mode == UiMode.CLASSIC
    val accent = if (classic) Color(0xFF00A8E0) else Color(0xFF62C9FF)
    val background = if (classic) listOf(Color(0xFF03070D), Color(0xFF102238), Color(0xFF03060B)) else listOf(Color(0xFF06162B), Color(0xFF183A65), Color(0xFF030A17))

    MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = background.first(), surface = Color(0xFF101D2B))) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(background))) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                StatusBar(accent)
                AnimatedContent(
                    targetState = page,
                    transitionSpec = { fadeIn(tween(100)) togetherWith fadeOut(tween(80)) },
                    label = "page"
                ) { target ->
                    Box(Modifier.fillMaxSize().pointerInput(target) {
                        detectHorizontalDragGestures(
                            onHorizontalDrag = { _, amount -> dragTotal += amount },
                            onDragEnd = {
                                if (dragTotal < -90) page = when (page) { Page.HOME -> Page.APPS; Page.APPS -> Page.TASKS; else -> Page.HOME }
                                if (dragTotal > 90) page = when (page) { Page.TASKS -> Page.APPS; Page.APPS -> Page.HOME; else -> Page.HOME }
                                dragTotal = 0f
                            }
                        )
                    }) {
                        when (target) {
                            Page.HOME -> HomePage(classic, accent, onApps = { page = Page.APPS }, onSettings = { page = Page.SETTINGS }, onLaunchShortcut = onLaunchShortcut)
                            Page.APPS -> AppsPage(apps, classic, accent, onRefreshApps, onLaunchApp)
                            Page.TASKS -> TasksPage(accent, onApps = { page = Page.APPS })
                            Page.SETTINGS -> SettingsPage(mode, onMode = { mode = it; onModeChanged(it) }, onBack = { page = Page.HOME })
                        }
                    }
                }
            }
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Page.values().take(3).forEachIndexed { i, p ->
                    Box(Modifier.padding(horizontal = 5.dp).size(if (page == p) 8.dp else 6.dp).clip(CircleShape).background(if (page == p) Color.White else Color.White.copy(alpha = .35f)))
                }
            }
            TextButton(onClick = { page = Page.SETTINGS }, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 8.dp, bottom = 30.dp)) {
                Text("THEME", color = accent, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun StatusBar(accent: Color) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(15_000) } }
    Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("MeeGo", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.weight(1f))
        Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
        Spacer(Modifier.width(9.dp))
        Icon(Icons.Default.Wifi, null, tint = accent, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Icon(Icons.Default.BatteryFull, null, tint = Color.White, modifier = Modifier.size(17.dp))
    }
}

@Composable
private fun HomePage(classic: Boolean, accent: Color, onApps: () -> Unit, onSettings: () -> Unit, onLaunchShortcut: (Shortcut) -> Unit) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(15_000) } }
    val locale = Locale.getDefault()
    val date = now.format(DateTimeFormatter.ofPattern("EEEE • d MMMM", locale)).uppercase(locale)
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White, fontSize = 66.sp, fontWeight = FontWeight.ExtraLight, letterSpacing = (-1).sp)
        Text(date, color = Color.White.copy(alpha = .78f), fontSize = 12.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(34.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            HomeShortcut("Phone", Icons.Default.Call, Color(0xFF75C900),  onClick = { onLaunchShortcut(Shortcut.PHONE) })
            HomeShortcut("Contacts", Icons.Default.Person, Color(0xFF168FE5), onClick = { onLaunchShortcut(Shortcut.CONTACTS) })
            HomeShortcut("Messages", Icons.Default.ChatBubble, Color(0xFF16A5D8), onClick = { onLaunchShortcut(Shortcut.MESSAGES) })
            HomeShortcut("Browser", Icons.Default.Language, Color(0xFF1789C8), onClick = { onLaunchShortcut(Shortcut.BROWSER) })
        }
        Spacer(Modifier.height(26.dp))
        Card(modifier = Modifier.fillMaxWidth().height(122.dp).clickable { onLaunchShortcut(Shortcut.CALENDAR) }, shape = RoundedCornerShape(if (classic) 8.dp else 20.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = if (classic) .08f else .12f))) {
            Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CalendarMonth, null, tint = accent, modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                    Text("Calendar", color = Color.White, fontWeight = FontWeight.Medium)
                    Text("Open your phone's calendar", color = Color.White.copy(alpha = .68f), fontSize = 12.sp)
                    Text(now.format(DateTimeFormatter.ofPattern("d MMMM", locale)), color = accent, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Color.White.copy(alpha = .7f))
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = onApps) { Text("All apps", color = accent) }
            TextButton(onClick = onSettings) { Text("Themes & settings", color = accent) }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun HomeShortcut(label: String, icon: ImageVector, tint: Color, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(64.dp).clip(RoundedCornerShape(19.dp)).background(Brush.linearGradient(listOf(tint.copy(alpha = .96f), tint.copy(alpha = .68f)))), contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = Color.White, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun AppsPage(tiles: List<AppTile>, classic: Boolean, accent: Color, onRefreshApps: () -> Unit, onLaunchApp: (AppTile) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(tiles, query) { tiles.filter { it.name.contains(query.trim(), ignoreCase = true) } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Applications", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
            IconButton(onClick = onRefreshApps) { Icon(Icons.Default.Refresh, "Refresh apps", tint = accent) }
        }
        OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search apps", color = Color.White.copy(alpha = .55f)) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = accent) },
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = accent, unfocusedBorderColor = Color.White.copy(alpha = .35f), cursorColor = accent))
        LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(bottom = 64.dp)) {
            items(filtered, key = { it.packageName + ":" + it.activityName }) { tile ->
                Column(Modifier.fillMaxWidth().clickable { onLaunchApp(tile) }.padding(vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(bitmap = tile.icon.asImageBitmap(), contentDescription = tile.name, modifier = Modifier.size(if (classic) 64.dp else 68.dp).clip(RoundedCornerShape(if (classic) 15.dp else 20.dp)))
                    Spacer(Modifier.height(5.dp))
                    Text(tile.name, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        if (filtered.isEmpty()) Text(if (tiles.isEmpty()) "No launchable apps found" else "No matching apps", color = Color.White.copy(alpha = .65f), modifier = Modifier.padding(12.dp))
    }
}

@Composable
private fun TasksPage(accent: Color, onApps: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = 18.dp)) {
        Text("Multitasking", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .09f)), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("Android manages running and recent apps", color = Color.White, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                Text("A third-party launcher cannot reliably read or close other apps' task previews without privileged access. This page stays honest rather than showing fake cards.", color = Color.White.copy(alpha = .72f), fontSize = 12.sp)
                TextButton(onClick = onApps) { Text("Open app drawer", color = accent) }
            }
        }
    }
}

@Composable
private fun SettingsPage(mode: UiMode, onMode: (UiMode) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Themes & settings", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(vertical = 16.dp))
        Text("Choose the visual style. The launcher does not access developer tools, private app data, or system files.", color = Color.White.copy(alpha = .72f), fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        listOf(UiMode.CLASSIC, UiMode.HYBRID).forEach { option ->
            val selected = mode == option
            Card(onClick = { onMode(option) }, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF16466F) else Color.White.copy(alpha = .08f))) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (option == UiMode.CLASSIC) "Classic 2011" else "Hybrid Modern", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(if (option == UiMode.CLASSIC) "Classic MeeGo-inspired styling" else "N9 identity with modern polish", color = Color.White.copy(alpha = .65f), fontSize = 11.sp)
                    }
                    RadioButton(selected = selected, onClick = { onMode(option) })
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("N9 Reborn • Prototype 0.9", color = Color.White.copy(alpha = .5f), fontSize = 11.sp)
        TextButton(onClick = onBack) { Text("Back to home", color = Color(0xFF62C9FF)) }
    }
}
