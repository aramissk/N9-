package com.meegoreborn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeeGoRebornApp() }
    }
}

private enum class UiMode { CLASSIC, HYBRID }
private enum class Page { HOME, APPS, TASKS, SETTINGS }

private data class AppTile(val name: String, val icon: ImageVector, val tint: Color)

@Composable
private fun MeeGoRebornApp() {
    var mode by remember { mutableStateOf(UiMode.HYBRID) }
    var page by remember { mutableStateOf(Page.HOME) }
    var dragTotal by remember { mutableFloatStateOf(0f) }

    val tiles = listOf(
        AppTile("Phone", Icons.Default.Call, Color(0xFF75C900)),
        AppTile("Contacts", Icons.Default.Person, Color(0xFF168FE5)),
        AppTile("Messages", Icons.Default.ChatBubble, Color(0xFF16A5D8)),
        AppTile("Browser", Icons.Default.Language, Color(0xFF1789C8)),
        AppTile("Camera", Icons.Default.CameraAlt, Color(0xFF66717D)),
        AppTile("Gallery", Icons.Default.Photo, Color(0xFF55A9D8)),
        AppTile("Music", Icons.Default.MusicNote, Color(0xFFE52C8A)),
        AppTile("Maps", Icons.Default.Explore, Color(0xFF6DAE35)),
        AppTile("Settings", Icons.Default.Settings, Color(0xFF87919A)),
        AppTile("Calendar", Icons.Default.CalendarToday, Color(0xFFE45A42)),
        AppTile("Videos", Icons.Default.PlayArrow, Color(0xFF4B78B9)),
        AppTile("Store", Icons.Default.ShoppingBag, Color(0xFF2878D0))
    )

    val classic = mode == UiMode.CLASSIC
    val bg = if (classic) Color(0xFF05070D) else Color(0xFF07172D)
    val accent = if (classic) Color(0xFF14A9E8) else Color(0xFF48B8F2)

    Surface(modifier = Modifier.fillMaxSize(), color = bg) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        if (classic) listOf(Color(0xFF02040A), Color(0xFF10192B), Color(0xFF03050A))
                        else listOf(Color(0xFF06152B), Color(0xFF102D55), Color(0xFF030A17))
                    )
                )
                .pointerInput(page) {
                    detectHorizontalDragGestures(
                        onHorizontalDrag = { _, amount -> dragTotal += amount },
                        onDragEnd = {
                            if (dragTotal < -65) page = when (page) {
                                Page.HOME -> Page.APPS
                                Page.APPS -> Page.TASKS
                                else -> Page.HOME
                            }
                            if (dragTotal > 65) page = when (page) {
                                Page.TASKS -> Page.APPS
                                Page.APPS -> Page.HOME
                                else -> Page.HOME
                            }
                            dragTotal = 0f
                        }
                    )
                }
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                StatusBar(accent)
                AnimatedContent(
                    targetState = page,
                    transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(120)) },
                    label = "page"
                ) { target ->
                    when (target) {
                        Page.HOME -> HomePage(classic, accent, onApps = { page = Page.APPS }, onSettings = { page = Page.SETTINGS })
                        Page.APPS -> AppsPage(tiles, classic, accent)
                        Page.TASKS -> TasksPage(classic, accent)
                        Page.SETTINGS -> SettingsPage(mode, onMode = { mode = it }, onBack = { page = Page.HOME })
                    }
                }
            }
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(3) { index ->
                    Box(
                        Modifier.padding(horizontal = 5.dp).size(if ((page.ordinal.coerceAtMost(2)) == index) 8.dp else 6.dp)
                            .clip(CircleShape).background(if (page.ordinal.coerceAtMost(2) == index) Color.White else Color.White.copy(alpha = .35f))
                    )
                }
            }
            TextButton(
                onClick = { page = Page.SETTINGS },
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 36.dp)
            ) { Text("MODE", color = accent, fontSize = 10.sp) }
        }
    }
}

@Composable
private fun StatusBar(accent: Color) {
    var time by remember { mutableStateOf(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))) }
    LaunchedEffect(Unit) {
        while (true) {
            time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
            delay(1000)
        }
    }
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("MeeGo", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.weight(1f))
        Text(time, color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
        Spacer(Modifier.width(12.dp))
        Icon(Icons.Default.Wifi, null, tint = accent, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(7.dp))
        Icon(Icons.Default.BatteryFull, null, tint = Color.White, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun HomePage(classic: Boolean, accent: Color, onApps: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(34.dp))
        Text("17:24", color = Color.White, fontSize = 58.sp, fontWeight = FontWeight.Light)
        Text("SATURDAY  •  07 NOVEMBER", color = Color.White.copy(alpha = .72f), fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(42.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            HomeShortcut("Phone", Icons.Default.Call, Color(0xFF75C900))
            HomeShortcut("Contacts", Icons.Default.Person, Color(0xFF168FE5))
            HomeShortcut("Messages", Icons.Default.ChatBubble, Color(0xFF16A5D8))
            HomeShortcut("Browser", Icons.Default.Language, Color(0xFF1789C8))
        }
        Spacer(Modifier.height(36.dp))
        Card(
            modifier = Modifier.fillMaxWidth().height(118.dp),
            shape = RoundedCornerShape(if (classic) 8.dp else 20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = if (classic) .07f else .11f))
        ) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
                Text(if (classic) "Nokia N9 • Classic experience" else "MeeGo Reborn • Hybrid", color = Color.White, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(7.dp))
                Text("Swipe left for apps  •  Swipe right to return", color = Color.White.copy(alpha = .7f), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = onApps) { Text("All apps", color = accent) }
            TextButton(onClick = onSettings) { Text("Settings", color = accent) }
        }
        Spacer(Modifier.height(42.dp))
    }
}

@Composable
private fun HomeShortcut(label: String, icon: ImageVector, tint: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)).background(tint), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}

@Composable
private fun AppsPage(tiles: List<AppTile>, classic: Boolean, accent: Color) {
    Column(Modifier.fillMaxSize()) {
        Text("Applications", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(top = 16.dp, bottom = 20.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
            contentPadding = PaddingValues(bottom = 70.dp)
        ) {
            items(tiles) { tile ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(if (classic) 55.dp else 59.dp)
                            .clip(RoundedCornerShape(if (classic) 15.dp else 19.dp))
                            .background(tile.tint),
                        contentAlignment = Alignment.Center
                    ) { Icon(tile.icon, null, tint = Color.White, modifier = Modifier.size(29.dp)) }
                    Spacer(Modifier.height(6.dp))
                    Text(tile.name, color = Color.White, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun TasksPage(classic: Boolean, accent: Color) {
    Column(Modifier.fillMaxSize()) {
        Text("Open applications", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(vertical = 18.dp))
        repeat(3) { index ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).height(112.dp),
                shape = RoundedCornerShape(if (classic) 7.dp else 17.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .10f))
            ) {
                Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)).background(listOf(Color(0xFF168FE5), Color(0xFF75C900), Color(0xFFE52C8A))[index]), contentAlignment = Alignment.Center) {
                        Icon(listOf(Icons.Default.Language, Icons.Default.Photo, Icons.Default.MusicNote)[index], null, tint = Color.White)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(listOf("Browser", "Gallery", "Music")[index], color = Color.White, fontWeight = FontWeight.Medium)
                        Text("Preview card • prototype", color = Color.White.copy(alpha = .6f), fontSize = 11.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Text("×", color = accent, fontSize = 24.sp)
                }
            }
        }
        Text("Prototype cards — real app task switching comes in a later build.", color = Color.White.copy(alpha = .55f), fontSize = 11.sp)
    }
}

@Composable
private fun SettingsPage(mode: UiMode, onMode: (UiMode) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Appearance", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(vertical = 18.dp))
        Text("Choose your MeeGo experience", color = Color.White.copy(alpha = .7f), fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        listOf(UiMode.CLASSIC, UiMode.HYBRID).forEach { option ->
            val selected = mode == option
            Card(
                onClick = { onMode(option) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (selected) Color(0xFF16466F) else Color.White.copy(alpha = .08f)
                )
            ) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (option == UiMode.CLASSIC) "Classic 2011" else "Hybrid Modern", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(if (option == UiMode.CLASSIC) "Faithful, nostalgic styling" else "Classic identity with modern polish", color = Color.White.copy(alpha = .65f), fontSize = 11.sp)
                    }
                    RadioButton(selected = selected, onClick = { onMode(option) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("MeeGo Reborn  •  Prototype 0.1", color = Color.White.copy(alpha = .45f), fontSize = 11.sp)
        TextButton(onClick = onBack) { Text("Back to home", color = Color(0xFF48B8F2)) }
    }
}
