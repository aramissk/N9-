# N9 Reborn Prototype 0.7

An Android launcher prototype inspired by Nokia N9 / MeeGo Harmattan.

## What's new in 0.7
- Live home-screen clock and date.
- Live battery percentage and charging state from Android.
- Network connection type indicator.
- Tap or long-press battery, network, and clock indicators for detail dialogs.
- Initial N9 Control Center with shortcuts to Android's official Wi-Fi, Bluetooth, Internet, Display, Sound, and Settings screens.
- Version metadata and GitHub Actions artifact updated to 0.7.

## Important limitations
- This is an early foundation build, not a finished operating-system replacement.
- Android restricts ordinary apps from directly toggling some radios and system features. The Control Center therefore opens official Android settings pages for those controls.
- Network speed currently reports aggregate download traffic observed by Android and is a basic estimate; upload speed and per-app traffic are not included.
- Signal strength, real notification shade replacement, customizable quick tiles, real recent-app management, and full notification access are not implemented yet.
- Recent-app switching remains a prototype screen.

## Build
Open the GitHub Actions tab and run **Build N9 APK** manually. The artifact is named `N9-APK-v0.7`.
