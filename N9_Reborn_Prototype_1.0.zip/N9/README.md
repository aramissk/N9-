# N9 Reborn — Prototype 0.9

Android launcher prototype inspired by Nokia N9 / MeeGo Harmattan. Tested build status: **not locally compiled in this workspace**; use the included GitHub Actions workflow to compile and verify before installing.

## Implemented in 0.9
- Declares Android `HOME` intent so Android can offer N9 Reborn as the default home launcher.
- Live system clock and localized date on the home screen.
- Working launch intents for Phone/dialer, Contacts, Messaging, Browser, and Calendar (opens an installed compatible app; availability depends on the device).
- App drawer lists launchable apps, launches them, supports search, and uses larger app icons with a lazy grid.
- Classic and Hybrid appearance modes are persisted locally.
- Basic page navigation and a simple multitasking information page that does not fabricate task previews.
- No developer-tool, root, kernel, firmware, or private-app-data access is implemented.

## Not yet implemented
- True Android AppWidget hosting (including Google Calendar widgets).
- System-level recent-task previews/closing. A normal third-party launcher cannot reliably provide this without privileged access or a carefully scoped accessibility service.
- A replacement for Android's system status/notification shade or fully functional quick-settings tiles.
- Rich per-icon Nokia artwork and HTC Sense-style 3D/Flip animations. The current build is a functional foundation, not the finished visual target.

## Build
Open the GitHub Actions workflow and run it manually. Verify the build succeeds before installing the APK. This source archive does not contain a prebuilt APK.


## Prototype 1.0 update
- Replaced the page fade with a directional horizontal slide + fade transition, closer to the N9-style page movement.
- Removed the launcher-drawn imitation status bar; Android's own status bar remains authoritative.
- Browser shortcut now opens a real web destination instead of a placeholder example domain.
- Bumped Android version to 1.0 (versionCode 10).

This remains a prototype. It has not been built or runtime-tested in this environment. Real system task previews and task closing are still not implemented because ordinary launchers do not have that privileged access.
