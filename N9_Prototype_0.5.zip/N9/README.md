# MeeGo Reborn / N9 Prototype 0.5

Android launcher prototype inspired by Nokia N9 / MeeGo.

## Version 0.5
- Adds Android HOME/DEFAULT intent categories so Android can offer N9 as a Home app.
- Reads launchable activities from the installed apps list.
- Shows installed app labels and icons in the Applications page.
- Tapping an app icon launches that app.
- Keeps the Classic and Hybrid appearance modes.

The app requests `QUERY_ALL_PACKAGES` so it can display the installed launchable apps. This is intended for sideloaded/testing builds; distribution through Google Play may be subject to package-visibility policy requirements.

## Build
From this directory run `gradle assembleDebug`, or use the GitHub Actions workflow.
