# MeeGo Reborn / N9 Prototype 0.6

Android launcher prototype inspired by Nokia N9 / MeeGo. This release builds on 0.5; the original archive is not modified.

## Version 0.6 changes
- Remembers the selected Classic or Hybrid mode after the app is closed.
- Adds app-name search to the Applications page.
- Adds a refresh control to reload launchable apps after installing or removing apps.
- Keeps separate launcher activities where an app publishes more than one launchable activity.
- Launches the selected activity directly, with a package-level fallback.
- Retains the Android HOME/DEFAULT intent categories and the existing Classic/Hybrid presentation.

## Known limitations
- The Tasks page is still a visual prototype; it does not enumerate or control Android's recent-task stack.
- This is an Android launcher, not a complete replacement for Xiaomi HyperOS system UI. A Xiaomi Themes package would be a separate deliverable and has not been generated in this release.
- `QUERY_ALL_PACKAGES` is used for the sideloaded prototype. Google Play distribution may require a narrower package-visibility implementation and policy review.

## Build
Open this project in Android Studio (JDK 17, Android Gradle Plugin compatible with Gradle 8.9), or run `gradle assembleDebug` from this directory. The debug APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.
